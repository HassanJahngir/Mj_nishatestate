import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import PropertyCard from '../components/PropertyCard'
import properties from '../data/properties'

export default function Properties(){
  return (
    <>
      <Navbar/>
      <main className="max-w-6xl mx-auto px-4 py-12">
        <h1 className="text-2xl font-bold">Properties for sale & rent</h1>
        <div className="mt-4 flex gap-3 flex-wrap">
          <select className="p-2 border rounded"><option>All types</option><option>House</option><option>Apartment</option><option>Plot / Land</option></select>
          <select className="p-2 border rounded"><option>All areas</option><option>Gulshan</option><option>City Center</option></select>
          <input placeholder="Min price" className="p-2 border rounded" />
          <input placeholder="Max price" className="p-2 border rounded" />
          <button className="px-4 py-2 btn-primary rounded" style={{background:'linear-gradient(90deg,#0b4f8a,#f0b429)', color:'white'}}>Search</button>
        </div>

        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {properties.map(p=> <PropertyCard key={p.id} p={p} />)}
        </div>
      </main>
      <Footer/>
    </>
  )
}
