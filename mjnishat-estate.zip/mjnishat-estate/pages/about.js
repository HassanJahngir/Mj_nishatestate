import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function About(){
  return (
    <>
      <Navbar/>
      <main className="max-w-5xl mx-auto px-4 py-12">
        <h1 className="text-3xl font-bold brand-gradient">About Us</h1>
        <p className="mt-4 text-slate-600">Muhammad Jahangir Nishat Estate provides honest, reliable, and professional real estate services. With years of experience in the local market, we help buyers, sellers, and investors make confident decisions.</p>
        <section className="mt-8 grid md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Our Mission</h3>
            <p className="text-sm text-slate-500 mt-2">To deliver transparent, client-focused real estate services that create lasting value.</p>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
            <h3 className="font-semibold">Our Services</h3>
            <ul className="mt-2 text-sm text-slate-500 list-disc ml-5">
              <li>Residential sales & purchases</li>
              <li>Commercial property deals</li>
              <li>Land and plots</li>
              <li>Rental and property management</li>
            </ul>
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-xl font-semibold">ہم کیوں منتخب کریں؟</h2>
          <p className="mt-2 text-slate-600">مقامی مہارت، مضبوط مذاکراتی صلاحیتیں، اور قابل اعتماد کلائنٹ روابط۔</p>
        </section>
      </main>
      <Footer/>
    </>
  )
}
