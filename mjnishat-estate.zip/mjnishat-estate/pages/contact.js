import Navbar from '../components/Navbar'
import Footer from '../components/Footer'

export default function Contact(){
  return (
    <>
      <Navbar/>
      <main className="max-w-4xl mx-auto px-4 py-12">
        <h1 className="text-2xl font-bold">Get in touch</h1>
        <p className="mt-2 text-slate-600">Call / WhatsApp: <a href="tel:03002022504" className="underline">0300-2022504</a></p>

        <div className="mt-6 bg-white p-6 rounded-lg shadow">
          <form action="#" method="POST" className="grid gap-4" onSubmit={(e)=>{e.preventDefault(); alert('Inquiry sent (demo)')}}>
            <input name="name" required placeholder="Your name" className="p-3 border rounded" />
            <input name="email" type="email" required placeholder="Your email" className="p-3 border rounded" />
            <input name="phone" placeholder="Phone / WhatsApp" className="p-3 border rounded" defaultValue="0300-2022504" />
            <textarea name="message" required placeholder="Message" className="p-3 border rounded h-28"></textarea>
            <div className="flex items-center justify-between">
              <button className="px-5 py-3 btn-primary rounded" style={{background:'linear-gradient(90deg,#0b4f8a,#f0b429)', color:'white'}}>Send message</button>
              <div className="text-sm text-slate-500">We will contact you within 24 hours.</div>
            </div>
          </form>
        </div>
      </main>
      <Footer/>
    </>
  )
}
