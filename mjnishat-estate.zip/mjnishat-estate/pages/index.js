import Link from 'next/link'
import Navbar from '../components/Navbar'
import Footer from '../components/Footer'
import PropertyCard from '../components/PropertyCard'
import properties from '../data/properties'
import { useState, useEffect } from 'react'
import Loader from '../components/Loader'

export default function Home(){
  const [loading, setLoading] = useState(true)
  useEffect(()=>{ const t=setTimeout(()=>setLoading(false),700); return ()=>clearTimeout(t)},[])
  if(loading) return <Loader/>
  return (
    <>
      <Navbar/>
      <main className="max-w-6xl mx-auto px-4 py-12">
        <section className="grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h1 className="text-4xl md:text-5xl font-extrabold leading-tight">
              Find your next home with <span className="brand-gradient">Muhammad Jahangir Nishat Estate</span>
            </h1>
            <p className="mt-4 text-slate-600">Building Dreams, Securing Futures — خوابوں کی تعمیر، مستقبل کا تحفظ</p>
            <div className="mt-6 flex gap-3">
              <Link href="/properties" className="inline-flex items-center px-6 py-3 btn-primary rounded-md shadow">View Properties</Link>
              <Link href="/contact" className="inline-flex items-center px-6 py-3 border rounded-md">Contact Us</Link>
            </div>
            <div className="mt-6 text-sm text-slate-500">Call / WhatsApp: <a className="text-slate-700 font-semibold" href="tel:03002022504">0300-2022504</a></div>
          </div>
          <div>
            <div className="rounded-2xl p-6 bg-white shadow-lg">
              <img src="/images/hero.jpg" alt="hero" className="w-full h-64 object-cover rounded-lg"/>
            </div>
          </div>
        </section>

        <section className="mt-12">
          <h2 className="text-2xl font-semibold">Featured Properties</h2>
          <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.slice(0,6).map(p=> <PropertyCard key={p.id} p={p} />)}
          </div>
        </section>
      </main>
      <Footer/>
      <a href={"https://wa.me/923002022504"} target="_blank" rel="noreferrer" className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 p-4 rounded-full shadow-lg text-white">WhatsApp</a>
    </>
  )
}
