export default function Footer(){
  return (
    <footer className="mt-12 text-center text-sm text-slate-500 pb-8">
      © {new Date().getFullYear()} Muhammad Jahangir Nishat Estate • Call: <a href="tel:03002022504" className="underline">0300-2022504</a>
    </footer>
  )
}
