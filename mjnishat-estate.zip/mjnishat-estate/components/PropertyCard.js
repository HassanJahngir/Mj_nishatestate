export default function PropertyCard({p}){
  return (
    <article className="bg-white rounded-lg overflow-hidden shadow">
      <img src={p.image} className="w-full h-44 object-cover" alt={p.title}/>
      <div className="p-4">
        <h3 className="font-semibold">{p.title}</h3>
        <p className="text-sm text-slate-500 mt-1">{p.details}</p>
        <p className="mt-2 font-semibold">{p.price}</p>
        <div className="mt-3 flex justify-between items-center">
          <a href="#" className="text-sm underline">Details</a>
          <a href={'tel:03002022504'} className="px-3 py-1 border rounded text-sm">Call</a>
        </div>
      </div>
    </article>
  )
}
