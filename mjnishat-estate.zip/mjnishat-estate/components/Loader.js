export default function Loader(){
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-white z-50">
      <div className="animate-spin rounded-full h-24 w-24 flex items-center justify-center" style={{borderTop: '6px solid var(--mjne-gold)', borderRight: '6px solid var(--mjne-blue)', borderBottom: '6px solid transparent', borderLeft: '6px solid transparent'}}>
        <svg width="48" height="48" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden>
          <path d="M30 65c10 18 26 22 36 8 22-34 40-54 44-58" fill="none" stroke="#0b4f8a" strokeLinecap="round" strokeLinejoin="round" strokeWidth="10"/>
          <path d="M32 69c12 14 28 18 44 0" fill="none" stroke="#f0b429" strokeLinecap="round" strokeLinejoin="round" strokeWidth="12"/>
        </svg>
      </div>
    </div>
  )
}
