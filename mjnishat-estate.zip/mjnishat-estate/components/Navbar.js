import Link from 'next/link'

export default function Navbar(){
  return (
    <header className="bg-white/90 sticky top-0 z-30 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <svg width="56" height="56" viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" aria-hidden>
            <circle cx="60" cy="60" r="58" fill="white" stroke="rgba(11,79,138,0.08)" strokeWidth="2"/>
            <path d="M30 65c10 18 26 22 36 8 22-34 40-54 44-58" fill="none" stroke="#0b4f8a" strokeLinecap="round" strokeLinejoin="round" strokeWidth="10"/>
            <path d="M32 69c12 14 28 18 44 0" fill="none" stroke="#f0b429" strokeLinecap="round" strokeLinejoin="round" strokeWidth="12"/>
          </svg>
          <div className="text-left">
            <div className="font-bold text-lg" style={{color: 'var(--mjne-blue)'}}>Muhammad Jahangir</div>
            <div className="text-sm font-semibold" style={{color: 'var(--mjne-gold)'}}>Nishat Estate</div>
          </div>
        </Link>

        <nav className="hidden md:flex gap-6 items-center text-sm">
          <Link href="/">Home</Link>
          <Link href="/about">About</Link>
          <Link href="/properties">Properties</Link>
          <Link href="/contact" className="px-4 py-2 btn-primary rounded-md text-sm">Contact</Link>
        </nav>

        <div className="md:hidden">
          <a href="tel:03002022504" className="px-3 py-2 border rounded-md text-sm">Call: 0300-2022504</a>
        </div>
      </div>
    </header>
  )
}
