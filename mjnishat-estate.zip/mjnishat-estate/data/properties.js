const properties = [
  {
    "id": 1,
    "title": "5 Marla Plot — Bahria Town",
    "details": "5 مرلہ پلاٹ — Bahria Town",
    "price": "PKR 25,00,000",
    "image": "/images/plot1.jpg"
  },
  {
    "id": 2,
    "title": "3-Bed House — Gulshan",
    "details": "3 بیڈ ہاؤس — Gulshan",
    "price": "PKR 12,500,000",
    "image": "/images/house1.jpg"
  },
  {
    "id": 3,
    "title": "2-Bed Apartment — City Center",
    "details": "2 بیڈ اپارٹمنٹ — City Center",
    "price": "PKR 45,000/mo",
    "image": "/images/apartment1.jpg"
  },
  {
    "id": 4,
    "title": "Shop — Main Market",
    "details": "دکان — مین مارکیٹ",
    "price": "PKR 8,500,000",
    "image": "/images/shop1.jpg"
  },
  {
    "id": 5,
    "title": "10 Marla Plot — New Development",
    "details": "10 مرلہ پلاٹ — New Development",
    "price": "PKR 40,000,000",
    "image": "/images/plot2.jpg"
  },
  {
    "id": 6,
    "title": "1-Bed Studio — Near University",
    "details": "1 بیڈ اسٹوڈیو — یونیورسٹی کے قریب",
    "price": "PKR 22,000/mo",
    "image": "/images/apartment2.jpg"
  }
];
export default properties;
